# Worker Payment System

## Overview:
This program facilitates the weekly payments of workers for Highridge Construction Company. It generates payment slips for workers based on their salary and gender, assigning them appropriate employee levels.

## Anaconda Version:
3.11.7 | packaged by Anaconda, Inc. 

### Instructions:
1. Ensure you have Python installed on your system.
2. Download the `mod_1_assignment.ipynb` file.
3. Open a terminal or command prompt and navigate to the directory containing the `mod_1_assignment.ipynb` file.
4. Run the script to generate payment slips for the workers.

### Files:
- `mod_1_assignment.ipynb`: Python script to generate payment slips for workers.