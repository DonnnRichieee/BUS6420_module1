## R Version:

## Overview:
This program facilitates the weekly payments of workers for Highridge Construction Company. It generates payment slips for workers based on their salary and gender, assigning them appropriate employee levels.

### Instructions:
1. Ensure you have R installed on your system.
2. Download the `module1_assignment_R` file.
3. Open R or RStudio.
4. Set the working directory to the directory containing the `worker_payment_system_R.R` file.
5. Run the script by sourcing the file in R or RStudio.
6. Follow the prompts to generate payment slips for the workers.

### Files:
- `worker_payment_system_R.R`: R script to generate payment slips for workers.
