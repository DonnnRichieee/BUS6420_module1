# Creating a dataframe with 3 columns "gender", "salary" and "Employee_level".
workers <- data.frame(gender = character(0), salary = numeric(0), Employee_level = character(0))

tryCatch({
  # Payment slip generation
  for (i in 1:410) {
    # Generate random salary and gender for each worker
    gender <- sample(c("Male", "Female"), 1)
    salary <- sample(seq(7000, 30000, by=1000), 1)
    
    # Append the result to workers dataframe
    workers <- rbind(workers, data.frame(gender = gender, salary = salary))
  }
  
  # Implement a for loop 
  for (i in 1:nrow(workers)) {
    if (10000 < workers[i, "salary"] & workers[i, "salary"] < 20000) {
      workers[i, "Employee_level"] <- "A1"
    } else if (7500 < workers[i, "salary"] & workers[i, "salary"] < 30000 & workers[i, "gender"] == "Female") {
      workers[i, "Employee_level"] <- "A5-F"
    } else {
      workers[i, "Employee_level"] <- "Regular"
    }
  }
}, error = function(e) {
  # Exception error
  cat("An error occurred:", e$message, "\n")
})

# Print payment slips
print(workers)

